/**
 */
package fr.l127.RessourceGraphique.impl;

import fr.l127.RessourceGraphique.Bloc;
import fr.l127.RessourceGraphique.BlocBinaire;
import fr.l127.RessourceGraphique.BlocIntermediaire;
import fr.l127.RessourceGraphique.BlocUnaire;
import fr.l127.RessourceGraphique.FonctionUnaire;
import fr.l127.RessourceGraphique.Initial;
import fr.l127.RessourceGraphique.Multiplication;
import fr.l127.RessourceGraphique.OperateurBinaire;
import fr.l127.RessourceGraphique.RessourceGraphique;
import fr.l127.RessourceGraphique.RessourceGraphiqueFactory;
import fr.l127.RessourceGraphique.RessourceGraphiquePackage;
import fr.l127.RessourceGraphique.Resultat;
import fr.l127.RessourceGraphique.Sinus;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RessourceGraphiquePackageImpl extends EPackageImpl implements RessourceGraphiquePackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ressourceGraphiqueEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass blocEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass blocIntermediaireEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass resultatEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass initialEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass blocUnaireEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass blocBinaireEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fonctionUnaireEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sinusEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass operateurBinaireEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass multiplicationEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private RessourceGraphiquePackageImpl() {
		super(eNS_URI, RessourceGraphiqueFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link RessourceGraphiquePackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static RessourceGraphiquePackage init() {
		if (isInited)
			return (RessourceGraphiquePackage) EPackage.Registry.INSTANCE
					.getEPackage(RessourceGraphiquePackage.eNS_URI);

		// Obtain or create and register package
		Object registeredRessourceGraphiquePackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		RessourceGraphiquePackageImpl theRessourceGraphiquePackage = registeredRessourceGraphiquePackage instanceof RessourceGraphiquePackageImpl
				? (RessourceGraphiquePackageImpl) registeredRessourceGraphiquePackage
				: new RessourceGraphiquePackageImpl();

		isInited = true;

		// Create package meta-data objects
		theRessourceGraphiquePackage.createPackageContents();

		// Initialize created meta-data
		theRessourceGraphiquePackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theRessourceGraphiquePackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(RessourceGraphiquePackage.eNS_URI, theRessourceGraphiquePackage);
		return theRessourceGraphiquePackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRessourceGraphique() {
		return ressourceGraphiqueEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getRessourceGraphique_Name() {
		return (EAttribute) ressourceGraphiqueEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getBloc() {
		return blocEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getBloc_Ressourcegraphique() {
		return (EReference) blocEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getBlocIntermediaire() {
		return blocIntermediaireEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getResultat() {
		return resultatEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getResultat_Entree() {
		return (EReference) resultatEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInitial() {
		return initialEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getBlocUnaire() {
		return blocUnaireEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getBlocUnaire_Entree() {
		return (EReference) blocUnaireEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getBlocBinaire() {
		return blocBinaireEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getBlocBinaire_Entree() {
		return (EReference) blocBinaireEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getFonctionUnaire() {
		return fonctionUnaireEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSinus() {
		return sinusEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getOperateurBinaire() {
		return operateurBinaireEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMultiplication() {
		return multiplicationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RessourceGraphiqueFactory getRessourceGraphiqueFactory() {
		return (RessourceGraphiqueFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		ressourceGraphiqueEClass = createEClass(RESSOURCE_GRAPHIQUE);
		createEAttribute(ressourceGraphiqueEClass, RESSOURCE_GRAPHIQUE__NAME);

		blocEClass = createEClass(BLOC);
		createEReference(blocEClass, BLOC__RESSOURCEGRAPHIQUE);

		blocIntermediaireEClass = createEClass(BLOC_INTERMEDIAIRE);

		resultatEClass = createEClass(RESULTAT);
		createEReference(resultatEClass, RESULTAT__ENTREE);

		initialEClass = createEClass(INITIAL);

		blocUnaireEClass = createEClass(BLOC_UNAIRE);
		createEReference(blocUnaireEClass, BLOC_UNAIRE__ENTREE);

		blocBinaireEClass = createEClass(BLOC_BINAIRE);
		createEReference(blocBinaireEClass, BLOC_BINAIRE__ENTREE);

		fonctionUnaireEClass = createEClass(FONCTION_UNAIRE);

		sinusEClass = createEClass(SINUS);

		operateurBinaireEClass = createEClass(OPERATEUR_BINAIRE);

		multiplicationEClass = createEClass(MULTIPLICATION);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		blocIntermediaireEClass.getESuperTypes().add(this.getBloc());
		resultatEClass.getESuperTypes().add(this.getBloc());
		initialEClass.getESuperTypes().add(this.getBloc());
		blocUnaireEClass.getESuperTypes().add(this.getBlocIntermediaire());
		blocBinaireEClass.getESuperTypes().add(this.getBlocIntermediaire());
		fonctionUnaireEClass.getESuperTypes().add(this.getBlocUnaire());
		sinusEClass.getESuperTypes().add(this.getFonctionUnaire());
		operateurBinaireEClass.getESuperTypes().add(this.getBlocBinaire());
		multiplicationEClass.getESuperTypes().add(this.getOperateurBinaire());

		// Initialize classes, features, and operations; add parameters
		initEClass(ressourceGraphiqueEClass, RessourceGraphique.class, "RessourceGraphique", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRessourceGraphique_Name(), ecorePackage.getEString(), "name", null, 0, 1,
				RessourceGraphique.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(blocEClass, Bloc.class, "Bloc", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBloc_Ressourcegraphique(), this.getRessourceGraphique(), null, "ressourcegraphique", null, 0,
				-1, Bloc.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(blocIntermediaireEClass, BlocIntermediaire.class, "BlocIntermediaire", IS_ABSTRACT, IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(resultatEClass, Resultat.class, "Resultat", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getResultat_Entree(), this.getBloc(), null, "entree", null, 1, 1, Resultat.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(initialEClass, Initial.class, "Initial", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(blocUnaireEClass, BlocUnaire.class, "BlocUnaire", IS_ABSTRACT, IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBlocUnaire_Entree(), this.getBloc(), null, "entree", null, 1, 1, BlocUnaire.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(blocBinaireEClass, BlocBinaire.class, "BlocBinaire", IS_ABSTRACT, IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBlocBinaire_Entree(), this.getBloc(), null, "entree", null, 2, 2, BlocBinaire.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(fonctionUnaireEClass, FonctionUnaire.class, "FonctionUnaire", IS_ABSTRACT, IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(sinusEClass, Sinus.class, "Sinus", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(operateurBinaireEClass, OperateurBinaire.class, "OperateurBinaire", IS_ABSTRACT, IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(multiplicationEClass, Multiplication.class, "Multiplication", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}

} //RessourceGraphiquePackageImpl
