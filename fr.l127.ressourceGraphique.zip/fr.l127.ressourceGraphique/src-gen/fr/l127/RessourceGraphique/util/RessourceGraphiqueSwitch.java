/**
 */
package fr.l127.RessourceGraphique.util;

import fr.l127.RessourceGraphique.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage
 * @generated
 */
public class RessourceGraphiqueSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static RessourceGraphiquePackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RessourceGraphiqueSwitch() {
		if (modelPackage == null) {
			modelPackage = RessourceGraphiquePackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case RessourceGraphiquePackage.RESSOURCE_GRAPHIQUE: {
			RessourceGraphique ressourceGraphique = (RessourceGraphique) theEObject;
			T result = caseRessourceGraphique(ressourceGraphique);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.BLOC: {
			Bloc bloc = (Bloc) theEObject;
			T result = caseBloc(bloc);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.BLOC_INTERMEDIAIRE: {
			BlocIntermediaire blocIntermediaire = (BlocIntermediaire) theEObject;
			T result = caseBlocIntermediaire(blocIntermediaire);
			if (result == null)
				result = caseBloc(blocIntermediaire);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.RESULTAT: {
			Resultat resultat = (Resultat) theEObject;
			T result = caseResultat(resultat);
			if (result == null)
				result = caseBloc(resultat);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.INITIAL: {
			Initial initial = (Initial) theEObject;
			T result = caseInitial(initial);
			if (result == null)
				result = caseBloc(initial);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.BLOC_UNAIRE: {
			BlocUnaire blocUnaire = (BlocUnaire) theEObject;
			T result = caseBlocUnaire(blocUnaire);
			if (result == null)
				result = caseBlocIntermediaire(blocUnaire);
			if (result == null)
				result = caseBloc(blocUnaire);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.BLOC_BINAIRE: {
			BlocBinaire blocBinaire = (BlocBinaire) theEObject;
			T result = caseBlocBinaire(blocBinaire);
			if (result == null)
				result = caseBlocIntermediaire(blocBinaire);
			if (result == null)
				result = caseBloc(blocBinaire);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.FONCTION_UNAIRE: {
			FonctionUnaire fonctionUnaire = (FonctionUnaire) theEObject;
			T result = caseFonctionUnaire(fonctionUnaire);
			if (result == null)
				result = caseBlocUnaire(fonctionUnaire);
			if (result == null)
				result = caseBlocIntermediaire(fonctionUnaire);
			if (result == null)
				result = caseBloc(fonctionUnaire);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.SINUS: {
			Sinus sinus = (Sinus) theEObject;
			T result = caseSinus(sinus);
			if (result == null)
				result = caseFonctionUnaire(sinus);
			if (result == null)
				result = caseBlocUnaire(sinus);
			if (result == null)
				result = caseBlocIntermediaire(sinus);
			if (result == null)
				result = caseBloc(sinus);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.OPERATEUR_BINAIRE: {
			OperateurBinaire operateurBinaire = (OperateurBinaire) theEObject;
			T result = caseOperateurBinaire(operateurBinaire);
			if (result == null)
				result = caseBlocBinaire(operateurBinaire);
			if (result == null)
				result = caseBlocIntermediaire(operateurBinaire);
			if (result == null)
				result = caseBloc(operateurBinaire);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case RessourceGraphiquePackage.MULTIPLICATION: {
			Multiplication multiplication = (Multiplication) theEObject;
			T result = caseMultiplication(multiplication);
			if (result == null)
				result = caseOperateurBinaire(multiplication);
			if (result == null)
				result = caseBlocBinaire(multiplication);
			if (result == null)
				result = caseBlocIntermediaire(multiplication);
			if (result == null)
				result = caseBloc(multiplication);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Ressource Graphique</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Ressource Graphique</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRessourceGraphique(RessourceGraphique object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Bloc</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Bloc</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBloc(Bloc object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Bloc Intermediaire</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Bloc Intermediaire</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBlocIntermediaire(BlocIntermediaire object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Resultat</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Resultat</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseResultat(Resultat object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Initial</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Initial</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInitial(Initial object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Bloc Unaire</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Bloc Unaire</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBlocUnaire(BlocUnaire object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Bloc Binaire</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Bloc Binaire</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBlocBinaire(BlocBinaire object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Fonction Unaire</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Fonction Unaire</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFonctionUnaire(FonctionUnaire object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Sinus</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Sinus</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSinus(Sinus object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Operateur Binaire</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Operateur Binaire</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOperateurBinaire(OperateurBinaire object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Multiplication</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Multiplication</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMultiplication(Multiplication object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //RessourceGraphiqueSwitch
