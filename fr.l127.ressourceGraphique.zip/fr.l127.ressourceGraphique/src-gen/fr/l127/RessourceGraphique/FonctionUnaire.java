/**
 */
package fr.l127.RessourceGraphique;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fonction Unaire</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage#getFonctionUnaire()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface FonctionUnaire extends BlocUnaire {
} // FonctionUnaire
