/**
 */
package fr.l127.RessourceGraphique;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bloc</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link fr.l127.RessourceGraphique.Bloc#getRessourcegraphique <em>Ressourcegraphique</em>}</li>
 * </ul>
 *
 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage#getBloc()
 * @model
 * @generated
 */
public interface Bloc extends EObject {
	/**
	 * Returns the value of the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * The list contents are of type {@link fr.l127.RessourceGraphique.RessourceGraphique}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ressourcegraphique</em>' containment reference list.
	 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage#getBloc_Ressourcegraphique()
	 * @model containment="true"
	 * @generated
	 */
	EList<RessourceGraphique> getRessourcegraphique();

} // Bloc
