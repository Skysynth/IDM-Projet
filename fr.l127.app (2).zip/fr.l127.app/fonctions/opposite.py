def opposite(colonne):
    longueur = len(colonne)
    resultat = [-colonne[i] for i in range(longueur)]
    return resultat