import math

def cons(entier):
    return [entier]