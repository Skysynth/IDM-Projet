from fonctions import *
def test2 (*colonnes) :
	return [min(colonnes[0],colonnes[1])]
