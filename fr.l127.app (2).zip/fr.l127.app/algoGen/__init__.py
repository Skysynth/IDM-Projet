from fonctions import *
from .algo import *
from .test import *
from .test2 import *