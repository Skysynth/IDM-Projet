from fonctions import *
def algo (*colonnes) :
	return [tan(cons(4)),sin(tan(cons(4))),add(colonnes[1],sin(tan(cons(4))))]
