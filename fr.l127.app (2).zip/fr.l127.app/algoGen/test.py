from fonctions import *
def test (*colonnes) :
	return [sin(colonnes[0])]
