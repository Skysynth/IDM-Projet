/**
 */
package RessourceGraphique;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Resultat</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RessourceGraphique.Resultat#getEntree <em>Entree</em>}</li>
 * </ul>
 *
 * @see RessourceGraphique.RessourceGraphiquePackage#getResultat()
 * @model abstract="true"
 * @generated
 */
public interface Resultat extends Bloc {
	/**
	 * Returns the value of the '<em><b>Entree</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entree</em>' reference.
	 * @see #setEntree(Bloc)
	 * @see RessourceGraphique.RessourceGraphiquePackage#getResultat_Entree()
	 * @model required="true"
	 * @generated
	 */
	Bloc getEntree();

	/**
	 * Sets the value of the '{@link RessourceGraphique.Resultat#getEntree <em>Entree</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Entree</em>' reference.
	 * @see #getEntree()
	 * @generated
	 */
	void setEntree(Bloc value);

} // Resultat
