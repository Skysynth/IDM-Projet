/**
 */
package RessourceGraphique;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RessourceGraphique.RessourceGraphiquePackage#getInitial()
 * @model
 * @generated
 */
public interface Initial extends Bloc {
} // Initial
