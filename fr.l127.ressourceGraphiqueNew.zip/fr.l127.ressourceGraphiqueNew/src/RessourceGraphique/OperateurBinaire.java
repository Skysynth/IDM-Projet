/**
 */
package RessourceGraphique;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operateur Binaire</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RessourceGraphique.RessourceGraphiquePackage#getOperateurBinaire()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface OperateurBinaire extends BlocBinaire {
} // OperateurBinaire
