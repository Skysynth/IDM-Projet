/**
 */
package RessourceGraphique;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Multiplication</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RessourceGraphique.RessourceGraphiquePackage#getMultiplication()
 * @model
 * @generated
 */
public interface Multiplication extends OperateurBinaire {
} // Multiplication
