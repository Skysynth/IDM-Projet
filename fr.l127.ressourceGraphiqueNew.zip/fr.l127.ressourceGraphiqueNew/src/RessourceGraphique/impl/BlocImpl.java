/**
 */
package RessourceGraphique.impl;

import RessourceGraphique.Bloc;
import RessourceGraphique.RessourceGraphique;
import RessourceGraphique.RessourceGraphiquePackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bloc</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link RessourceGraphique.impl.BlocImpl#getRessourcegraphique <em>Ressourcegraphique</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BlocImpl extends MinimalEObjectImpl.Container implements Bloc {
	/**
	 * The cached value of the '{@link #getRessourcegraphique() <em>Ressourcegraphique</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRessourcegraphique()
	 * @generated
	 * @ordered
	 */
	protected EList<RessourceGraphique> ressourcegraphique;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BlocImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RessourceGraphiquePackage.Literals.BLOC;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<RessourceGraphique> getRessourcegraphique() {
		if (ressourcegraphique == null) {
			ressourcegraphique = new EObjectContainmentEList<RessourceGraphique>(RessourceGraphique.class, this, RessourceGraphiquePackage.BLOC__RESSOURCEGRAPHIQUE);
		}
		return ressourcegraphique;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case RessourceGraphiquePackage.BLOC__RESSOURCEGRAPHIQUE:
				return ((InternalEList<?>)getRessourcegraphique()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case RessourceGraphiquePackage.BLOC__RESSOURCEGRAPHIQUE:
				return getRessourcegraphique();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case RessourceGraphiquePackage.BLOC__RESSOURCEGRAPHIQUE:
				getRessourcegraphique().clear();
				getRessourcegraphique().addAll((Collection<? extends RessourceGraphique>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case RessourceGraphiquePackage.BLOC__RESSOURCEGRAPHIQUE:
				getRessourcegraphique().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case RessourceGraphiquePackage.BLOC__RESSOURCEGRAPHIQUE:
				return ressourcegraphique != null && !ressourcegraphique.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //BlocImpl
