/**
 */
package RessourceGraphique.impl;

import RessourceGraphique.Initial;
import RessourceGraphique.RessourceGraphiquePackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Initial</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InitialImpl extends BlocImpl implements Initial {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InitialImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RessourceGraphiquePackage.Literals.INITIAL;
	}

} //InitialImpl
