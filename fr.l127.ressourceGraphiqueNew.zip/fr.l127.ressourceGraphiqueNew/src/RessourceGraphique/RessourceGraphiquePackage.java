/**
 */
package RessourceGraphique;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see RessourceGraphique.RessourceGraphiqueFactory
 * @model kind="package"
 * @generated
 */
public interface RessourceGraphiquePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "RessourceGraphique";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/ressourceGraphique";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "ressourceGraphique";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RessourceGraphiquePackage eINSTANCE = RessourceGraphique.impl.RessourceGraphiquePackageImpl.init();

	/**
	 * The meta object id for the '{@link RessourceGraphique.impl.RessourceGraphiqueImpl <em>Ressource Graphique</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.impl.RessourceGraphiqueImpl
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getRessourceGraphique()
	 * @generated
	 */
	int RESSOURCE_GRAPHIQUE = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESSOURCE_GRAPHIQUE__NAME = 0;

	/**
	 * The number of structural features of the '<em>Ressource Graphique</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESSOURCE_GRAPHIQUE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Ressource Graphique</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESSOURCE_GRAPHIQUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.impl.BlocImpl <em>Bloc</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.impl.BlocImpl
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getBloc()
	 * @generated
	 */
	int BLOC = 1;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC__RESSOURCEGRAPHIQUE = 0;

	/**
	 * The number of structural features of the '<em>Bloc</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Bloc</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.BlocIntermediaire <em>Bloc Intermediaire</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.BlocIntermediaire
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getBlocIntermediaire()
	 * @generated
	 */
	int BLOC_INTERMEDIAIRE = 2;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_INTERMEDIAIRE__RESSOURCEGRAPHIQUE = BLOC__RESSOURCEGRAPHIQUE;

	/**
	 * The number of structural features of the '<em>Bloc Intermediaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_INTERMEDIAIRE_FEATURE_COUNT = BLOC_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Bloc Intermediaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_INTERMEDIAIRE_OPERATION_COUNT = BLOC_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.impl.ResultatImpl <em>Resultat</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.impl.ResultatImpl
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getResultat()
	 * @generated
	 */
	int RESULTAT = 3;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESULTAT__RESSOURCEGRAPHIQUE = BLOC__RESSOURCEGRAPHIQUE;

	/**
	 * The feature id for the '<em><b>Entree</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESULTAT__ENTREE = BLOC_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Resultat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESULTAT_FEATURE_COUNT = BLOC_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Resultat</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RESULTAT_OPERATION_COUNT = BLOC_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.impl.InitialImpl <em>Initial</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.impl.InitialImpl
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getInitial()
	 * @generated
	 */
	int INITIAL = 4;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL__RESSOURCEGRAPHIQUE = BLOC__RESSOURCEGRAPHIQUE;

	/**
	 * The number of structural features of the '<em>Initial</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL_FEATURE_COUNT = BLOC_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Initial</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL_OPERATION_COUNT = BLOC_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.BlocUnaire <em>Bloc Unaire</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.BlocUnaire
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getBlocUnaire()
	 * @generated
	 */
	int BLOC_UNAIRE = 5;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_UNAIRE__RESSOURCEGRAPHIQUE = BLOC_INTERMEDIAIRE__RESSOURCEGRAPHIQUE;

	/**
	 * The feature id for the '<em><b>Entree</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_UNAIRE__ENTREE = BLOC_INTERMEDIAIRE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Bloc Unaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_UNAIRE_FEATURE_COUNT = BLOC_INTERMEDIAIRE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Bloc Unaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_UNAIRE_OPERATION_COUNT = BLOC_INTERMEDIAIRE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.BlocBinaire <em>Bloc Binaire</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.BlocBinaire
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getBlocBinaire()
	 * @generated
	 */
	int BLOC_BINAIRE = 6;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_BINAIRE__RESSOURCEGRAPHIQUE = BLOC_INTERMEDIAIRE__RESSOURCEGRAPHIQUE;

	/**
	 * The feature id for the '<em><b>Entree</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_BINAIRE__ENTREE = BLOC_INTERMEDIAIRE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Bloc Binaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_BINAIRE_FEATURE_COUNT = BLOC_INTERMEDIAIRE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Bloc Binaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOC_BINAIRE_OPERATION_COUNT = BLOC_INTERMEDIAIRE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.FonctionUnaire <em>Fonction Unaire</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.FonctionUnaire
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getFonctionUnaire()
	 * @generated
	 */
	int FONCTION_UNAIRE = 7;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONCTION_UNAIRE__RESSOURCEGRAPHIQUE = BLOC_UNAIRE__RESSOURCEGRAPHIQUE;

	/**
	 * The feature id for the '<em><b>Entree</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONCTION_UNAIRE__ENTREE = BLOC_UNAIRE__ENTREE;

	/**
	 * The number of structural features of the '<em>Fonction Unaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONCTION_UNAIRE_FEATURE_COUNT = BLOC_UNAIRE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Fonction Unaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONCTION_UNAIRE_OPERATION_COUNT = BLOC_UNAIRE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.impl.SinusImpl <em>Sinus</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.impl.SinusImpl
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getSinus()
	 * @generated
	 */
	int SINUS = 8;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINUS__RESSOURCEGRAPHIQUE = FONCTION_UNAIRE__RESSOURCEGRAPHIQUE;

	/**
	 * The feature id for the '<em><b>Entree</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINUS__ENTREE = FONCTION_UNAIRE__ENTREE;

	/**
	 * The number of structural features of the '<em>Sinus</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINUS_FEATURE_COUNT = FONCTION_UNAIRE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Sinus</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SINUS_OPERATION_COUNT = FONCTION_UNAIRE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.OperateurBinaire <em>Operateur Binaire</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.OperateurBinaire
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getOperateurBinaire()
	 * @generated
	 */
	int OPERATEUR_BINAIRE = 9;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATEUR_BINAIRE__RESSOURCEGRAPHIQUE = BLOC_BINAIRE__RESSOURCEGRAPHIQUE;

	/**
	 * The feature id for the '<em><b>Entree</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATEUR_BINAIRE__ENTREE = BLOC_BINAIRE__ENTREE;

	/**
	 * The number of structural features of the '<em>Operateur Binaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATEUR_BINAIRE_FEATURE_COUNT = BLOC_BINAIRE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Operateur Binaire</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPERATEUR_BINAIRE_OPERATION_COUNT = BLOC_BINAIRE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link RessourceGraphique.impl.MultiplicationImpl <em>Multiplication</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see RessourceGraphique.impl.MultiplicationImpl
	 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getMultiplication()
	 * @generated
	 */
	int MULTIPLICATION = 10;

	/**
	 * The feature id for the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLICATION__RESSOURCEGRAPHIQUE = OPERATEUR_BINAIRE__RESSOURCEGRAPHIQUE;

	/**
	 * The feature id for the '<em><b>Entree</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLICATION__ENTREE = OPERATEUR_BINAIRE__ENTREE;

	/**
	 * The number of structural features of the '<em>Multiplication</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLICATION_FEATURE_COUNT = OPERATEUR_BINAIRE_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Multiplication</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLICATION_OPERATION_COUNT = OPERATEUR_BINAIRE_OPERATION_COUNT + 0;


	/**
	 * Returns the meta object for class '{@link RessourceGraphique.RessourceGraphique <em>Ressource Graphique</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ressource Graphique</em>'.
	 * @see RessourceGraphique.RessourceGraphique
	 * @generated
	 */
	EClass getRessourceGraphique();

	/**
	 * Returns the meta object for the attribute '{@link RessourceGraphique.RessourceGraphique#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see RessourceGraphique.RessourceGraphique#getName()
	 * @see #getRessourceGraphique()
	 * @generated
	 */
	EAttribute getRessourceGraphique_Name();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.Bloc <em>Bloc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bloc</em>'.
	 * @see RessourceGraphique.Bloc
	 * @generated
	 */
	EClass getBloc();

	/**
	 * Returns the meta object for the containment reference list '{@link RessourceGraphique.Bloc#getRessourcegraphique <em>Ressourcegraphique</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ressourcegraphique</em>'.
	 * @see RessourceGraphique.Bloc#getRessourcegraphique()
	 * @see #getBloc()
	 * @generated
	 */
	EReference getBloc_Ressourcegraphique();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.BlocIntermediaire <em>Bloc Intermediaire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bloc Intermediaire</em>'.
	 * @see RessourceGraphique.BlocIntermediaire
	 * @generated
	 */
	EClass getBlocIntermediaire();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.Resultat <em>Resultat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Resultat</em>'.
	 * @see RessourceGraphique.Resultat
	 * @generated
	 */
	EClass getResultat();

	/**
	 * Returns the meta object for the reference '{@link RessourceGraphique.Resultat#getEntree <em>Entree</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Entree</em>'.
	 * @see RessourceGraphique.Resultat#getEntree()
	 * @see #getResultat()
	 * @generated
	 */
	EReference getResultat_Entree();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.Initial <em>Initial</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Initial</em>'.
	 * @see RessourceGraphique.Initial
	 * @generated
	 */
	EClass getInitial();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.BlocUnaire <em>Bloc Unaire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bloc Unaire</em>'.
	 * @see RessourceGraphique.BlocUnaire
	 * @generated
	 */
	EClass getBlocUnaire();

	/**
	 * Returns the meta object for the reference '{@link RessourceGraphique.BlocUnaire#getEntree <em>Entree</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Entree</em>'.
	 * @see RessourceGraphique.BlocUnaire#getEntree()
	 * @see #getBlocUnaire()
	 * @generated
	 */
	EReference getBlocUnaire_Entree();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.BlocBinaire <em>Bloc Binaire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bloc Binaire</em>'.
	 * @see RessourceGraphique.BlocBinaire
	 * @generated
	 */
	EClass getBlocBinaire();

	/**
	 * Returns the meta object for the reference list '{@link RessourceGraphique.BlocBinaire#getEntree <em>Entree</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Entree</em>'.
	 * @see RessourceGraphique.BlocBinaire#getEntree()
	 * @see #getBlocBinaire()
	 * @generated
	 */
	EReference getBlocBinaire_Entree();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.FonctionUnaire <em>Fonction Unaire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fonction Unaire</em>'.
	 * @see RessourceGraphique.FonctionUnaire
	 * @generated
	 */
	EClass getFonctionUnaire();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.Sinus <em>Sinus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Sinus</em>'.
	 * @see RessourceGraphique.Sinus
	 * @generated
	 */
	EClass getSinus();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.OperateurBinaire <em>Operateur Binaire</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Operateur Binaire</em>'.
	 * @see RessourceGraphique.OperateurBinaire
	 * @generated
	 */
	EClass getOperateurBinaire();

	/**
	 * Returns the meta object for class '{@link RessourceGraphique.Multiplication <em>Multiplication</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Multiplication</em>'.
	 * @see RessourceGraphique.Multiplication
	 * @generated
	 */
	EClass getMultiplication();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	RessourceGraphiqueFactory getRessourceGraphiqueFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link RessourceGraphique.impl.RessourceGraphiqueImpl <em>Ressource Graphique</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.impl.RessourceGraphiqueImpl
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getRessourceGraphique()
		 * @generated
		 */
		EClass RESSOURCE_GRAPHIQUE = eINSTANCE.getRessourceGraphique();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RESSOURCE_GRAPHIQUE__NAME = eINSTANCE.getRessourceGraphique_Name();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.impl.BlocImpl <em>Bloc</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.impl.BlocImpl
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getBloc()
		 * @generated
		 */
		EClass BLOC = eINSTANCE.getBloc();

		/**
		 * The meta object literal for the '<em><b>Ressourcegraphique</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOC__RESSOURCEGRAPHIQUE = eINSTANCE.getBloc_Ressourcegraphique();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.BlocIntermediaire <em>Bloc Intermediaire</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.BlocIntermediaire
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getBlocIntermediaire()
		 * @generated
		 */
		EClass BLOC_INTERMEDIAIRE = eINSTANCE.getBlocIntermediaire();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.impl.ResultatImpl <em>Resultat</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.impl.ResultatImpl
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getResultat()
		 * @generated
		 */
		EClass RESULTAT = eINSTANCE.getResultat();

		/**
		 * The meta object literal for the '<em><b>Entree</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RESULTAT__ENTREE = eINSTANCE.getResultat_Entree();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.impl.InitialImpl <em>Initial</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.impl.InitialImpl
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getInitial()
		 * @generated
		 */
		EClass INITIAL = eINSTANCE.getInitial();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.BlocUnaire <em>Bloc Unaire</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.BlocUnaire
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getBlocUnaire()
		 * @generated
		 */
		EClass BLOC_UNAIRE = eINSTANCE.getBlocUnaire();

		/**
		 * The meta object literal for the '<em><b>Entree</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOC_UNAIRE__ENTREE = eINSTANCE.getBlocUnaire_Entree();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.BlocBinaire <em>Bloc Binaire</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.BlocBinaire
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getBlocBinaire()
		 * @generated
		 */
		EClass BLOC_BINAIRE = eINSTANCE.getBlocBinaire();

		/**
		 * The meta object literal for the '<em><b>Entree</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOC_BINAIRE__ENTREE = eINSTANCE.getBlocBinaire_Entree();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.FonctionUnaire <em>Fonction Unaire</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.FonctionUnaire
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getFonctionUnaire()
		 * @generated
		 */
		EClass FONCTION_UNAIRE = eINSTANCE.getFonctionUnaire();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.impl.SinusImpl <em>Sinus</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.impl.SinusImpl
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getSinus()
		 * @generated
		 */
		EClass SINUS = eINSTANCE.getSinus();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.OperateurBinaire <em>Operateur Binaire</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.OperateurBinaire
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getOperateurBinaire()
		 * @generated
		 */
		EClass OPERATEUR_BINAIRE = eINSTANCE.getOperateurBinaire();

		/**
		 * The meta object literal for the '{@link RessourceGraphique.impl.MultiplicationImpl <em>Multiplication</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see RessourceGraphique.impl.MultiplicationImpl
		 * @see RessourceGraphique.impl.RessourceGraphiquePackageImpl#getMultiplication()
		 * @generated
		 */
		EClass MULTIPLICATION = eINSTANCE.getMultiplication();

	}

} //RessourceGraphiquePackage
