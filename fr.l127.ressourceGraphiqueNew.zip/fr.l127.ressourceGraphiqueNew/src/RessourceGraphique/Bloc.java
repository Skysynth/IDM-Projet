/**
 */
package RessourceGraphique;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bloc</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RessourceGraphique.Bloc#getRessourcegraphique <em>Ressourcegraphique</em>}</li>
 * </ul>
 *
 * @see RessourceGraphique.RessourceGraphiquePackage#getBloc()
 * @model
 * @generated
 */
public interface Bloc extends EObject {
	/**
	 * Returns the value of the '<em><b>Ressourcegraphique</b></em>' containment reference list.
	 * The list contents are of type {@link RessourceGraphique.RessourceGraphique}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ressourcegraphique</em>' containment reference list.
	 * @see RessourceGraphique.RessourceGraphiquePackage#getBloc_Ressourcegraphique()
	 * @model containment="true"
	 * @generated
	 */
	EList<RessourceGraphique> getRessourcegraphique();

} // Bloc
