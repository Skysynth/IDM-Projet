/**
 */
package fr.l127.RessourceGraphique;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage#getInitial()
 * @model
 * @generated
 */
public interface Initial extends Bloc {
} // Initial
