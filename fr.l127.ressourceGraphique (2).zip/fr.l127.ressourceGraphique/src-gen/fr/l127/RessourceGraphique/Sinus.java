/**
 */
package fr.l127.RessourceGraphique;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sinus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage#getSinus()
 * @model
 * @generated
 */
public interface Sinus extends FonctionUnaire {
} // Sinus
