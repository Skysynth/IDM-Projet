/**
 */
package fr.l127.RessourceGraphique;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operateur Binaire</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage#getOperateurBinaire()
 * @model interface="true" abstract="true"
 * @generated
 */
public interface OperateurBinaire extends BlocBinaire {
} // OperateurBinaire
