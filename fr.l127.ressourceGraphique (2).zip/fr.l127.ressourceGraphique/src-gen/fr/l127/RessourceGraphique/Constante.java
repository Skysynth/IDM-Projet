/**
 */
package fr.l127.RessourceGraphique;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Constante</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage#getConstante()
 * @model
 * @generated
 */
public interface Constante extends BlocUnaire {
} // Constante
