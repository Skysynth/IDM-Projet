/**
 */
package fr.l127.RessourceGraphique;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Bloc</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.l127.RessourceGraphique.RessourceGraphiquePackage#getBloc()
 * @model abstract="true"
 * @generated
 */
public interface Bloc extends EObject {

} // Bloc
