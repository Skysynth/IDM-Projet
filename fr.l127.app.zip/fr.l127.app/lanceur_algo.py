
from algoGen import *
import csv
import sys

def flatten_list(liste):
    # Vérifier si la liste contient des sous-listes
    if any(isinstance(elem, list) for elem in liste):
        # Si oui, appliquer le flatten
        return [item for sublist in liste for item in sublist]
    else:
        # Sinon, renvoyer simplement la liste
        return liste
    
def ecrire_csv(donnees, nom_fichier):
    # Vérifier si les données sont une liste de listes ou une simple liste
    if all(isinstance(el, list) for el in donnees):
        liste_de_listes = donnees
    else:
        liste_de_listes = [donnees]  # Convertir en liste de listes pour une seule colonne

    # Calculer la longueur maximale des sous-listes
    longueur_max = max(len(sous_liste) for sous_liste in liste_de_listes)
    
    # Compléter les sous-listes plus courtes avec des chaînes vides
    liste_normalisee = [sous_liste + [''] * (longueur_max - len(sous_liste)) for sous_liste in liste_de_listes]

    # Ouvrir le fichier CSV en mode écriture
    with open(nom_fichier, 'w', newline='', encoding='utf-8') as fichier:
        writer = csv.writer(fichier)

        # Écrire les données dans le fichier CSV
        for i in range(longueur_max):
            writer.writerow([sous_liste[i] for sous_liste in liste_normalisee])


    
def lire_csv_et_executer_add(fonction, input_csv, output_csv):
    colonnes = []

    # Lecture du fichier CSV
    with open(input_csv, newline='') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            # Conversion des éléments de la ligne en entiers si possible
            colonnes.append([int(item) if item.isdigit() else item for item in row])
            print(colonnes)
    # Exécution de la fonction add
    resultat = fonction(*colonnes)
    print(resultat)

    # resultat = flatten_list(resultat)

    # print(resultat)


    # # Écriture du résultat dans un fichier CSV
    # with open(output_csv, 'w', newline='') as csvfile:
    #     writer = csv.writer(csvfile)
    #     for val in resultat:
    #         writer.writerow([val])

    ecrire_csv(resultat, output_csv)
if __name__ == "__main__":
    # Vérifier si un argument de fichier a été fourni
    if len(sys.argv) > 3:
        script = sys.argv[1]
        input_csv = sys.argv[2]
        output_csv = sys.argv[3]
        fonction = globals()[script]         
        lire_csv_et_executer_add(fonction, input_csv, output_csv)
    else:
        println("Veuillez spécifier un fichier CSV en argument.")