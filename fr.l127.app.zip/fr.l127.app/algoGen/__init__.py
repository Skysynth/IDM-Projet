from fonctions import *
from .algo import *